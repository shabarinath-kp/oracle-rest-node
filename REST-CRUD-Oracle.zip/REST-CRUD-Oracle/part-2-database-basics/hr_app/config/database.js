module.exports = {
  hrPool: {
    user: 'system',
    password: 'manager',
  
    poolMin: 10,
    poolMax: 10,
    poolIncrement: 0
  }
};
