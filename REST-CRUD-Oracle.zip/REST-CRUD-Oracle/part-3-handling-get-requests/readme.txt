node index.js


http://localhost:3000/api/employees/
http://localhost:3000/api/employees/100
