module.exports = {
  hrPool: {
    user: 'hr',
    password: 'hr',
   
    poolMin: 10,
    poolMax: 10,
    poolIncrement: 0
  }
};
